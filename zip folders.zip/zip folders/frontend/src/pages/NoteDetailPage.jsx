import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import api from "../lib/axios";
import toast from "react-hot-toast";
import { ArrowLeftIcon, LoaderIcon, Trash2Icon } from "lucide-react";

const NoteDetailPage = () => {

    const [note, setNote] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const navigate = useNavigate();

    const handleDelete = async () => {

        if (!window.confirm("Are you sure want to delete this note?")) return;

        try {
            await api.delete(`/notes/${id}`)
            toast.success("Note deleted successfully")
            navigate("/")
        } catch (error) {
            console.log("Failed to delete the note", error);
            toast.error("Failed to delete note")
        }
    }
    const handleSave = async () => {
        if (!note.title.trim() || !note.content.trim()) {
            toast.error("Please ass a title or content");
            return;
        }

        setSaving(true);

        try {
            await api.put(`/notes/${id}`,note);
            toast.success("Note Updated successfully");
            navigate("/");
        } catch (error) {
            toast.error("Error in Update Note");
            console.log("Failed to Update note",error);

        } finally {
            setSaving(false)
        }
    };

    const { id } = useParams();

    useEffect(() => {
        const fetchNote = async () => {
            try {
                const res = await api.get(`/notes/${id}`)
                setNote(res.data)
            } catch (error) {
                console.log("Error in fetching Note", error)
                toast.error("Failed to fetch the note")
            } finally {
                setLoading(false)
            }
        };
        fetchNote();
    }, [id]);

    console.log({ note });

    if (loading) {
        return (
            <div className="min-h-screen bg-base-200 flex items-center justify-center">
                <LoaderIcon className="animate-spin size-30" />
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-base-200">
            <div className="container mx-auto px-4 py-8">
                <div className="max-w-2xl mx-auto">
                    <div className="flex items-center justify-between mb-6">
                        <Link to="/" className="btn btn-ghost">
                            <ArrowLeftIcon className="h-5 w-5" />
                            Back to Notes
                        </Link>
                        <button onClick={handleDelete} className="btn btn-error btn-outline">
                            <Trash2Icon className="h-5 w-5" />
                            Delete Note
                        </button>
                    </div>
                    <div className="card bg-base-100">
                        <div className="card-body">
                            <div className="form-control mb-4">
                                <label className="label">
                                    <span className="label-text">Title</span>
                                </label>
                                <input type="text"
                                    placeholder="Note Title"
                                    className="input input-bordered"
                                    value={note.title}
                                    onChange={(e) => setNote({ ...note, title: e.target.value })}
                                />
                            </div>
                            <div className="form-control mb-4">
                                <label className="label">
                                    <span className="label-text">Content</span>
                                </label>
                                <textarea
                                    placeholder="Write your Note here......"
                                    className="textarea textarea-bordered h-32"
                                    value={note.content}
                                    onChange={(e) => setNote({ ...note, content: e.target.value })}
                                />
                            </div>
                            <div className="card-actions justify-end">
                                <button className="btn btn-primary" disabled={saving} onClick={handleSave}>
                                    {saving ? "Saving....." : "Save Changes"}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default NoteDetailPage;